// let wszystkieKryptoalutyKurs = [];

// const proxy = `https://cors-anywhere.herokuapp.com/`;
// const apiKryptowaluty = `${proxy}https://bitbay.net/API/Public/BTCPLN/orderbook.json`;

// fetch(apiKryptowaluty)
//   .then((response) => {
//     return response.json();
//   })
//   .then((dane) => {
//     for (let i = 0; i < 1; i++) {
//       console.log(dane.asks[0][0]);
//       wszystkieKryptoalutyKurs.push(dane.asks[0][0]);
//     }
//   });
// //

const bazaKryptowalut = [
  "BTC",

  "ETH",

  "LSK",

  "LTC",

  "GAME",

  "DASH",

  "BCC",

  "BTG",

  "XIN",

  "XRP",

  "ZEC",

  "GNT",

  "OMG",

  "ZRX",

  "PAY",

  "BAT",

  "REP",

  "NEU",

  "TRX",

  "BOB",

  "BSV",

  "XLM",

  "USDC",
];

const bazaKryptowalutCoingecko = [
  "Bitcoin",
  "Ethereum",
  "BinanceCoin",
  "Tether",
  "Cardano",
  "USDCoin",
  "Solana",
  "XRP",
  "Terra",
  "Polkadot",
  "Dogecoin",
];
